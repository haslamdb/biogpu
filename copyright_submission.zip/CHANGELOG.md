# BioGPU Changelog

## [v1.0.0] - 2025-05-30
- Working pipeline with real data